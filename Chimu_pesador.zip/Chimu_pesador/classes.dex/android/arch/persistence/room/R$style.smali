.class public final Landroid/arch/persistence/room/R$style;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/arch/persistence/room/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static final TextAppearance_Compat_Notification:I = 0x7f0f00fa

.field public static final TextAppearance_Compat_Notification_Info:I = 0x7f0f00fb

.field public static final TextAppearance_Compat_Notification_Line2:I = 0x7f0f00fd

.field public static final TextAppearance_Compat_Notification_Time:I = 0x7f0f0100

.field public static final TextAppearance_Compat_Notification_Title:I = 0x7f0f0102

.field public static final Widget_Compat_NotificationActionContainer:I = 0x7f0f0179

.field public static final Widget_Compat_NotificationActionText:I = 0x7f0f017a


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
