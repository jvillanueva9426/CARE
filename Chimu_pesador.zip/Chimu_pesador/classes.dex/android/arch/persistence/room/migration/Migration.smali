.class public abstract Landroid/arch/persistence/room/migration/Migration;
.super Ljava/lang/Object;
.source "Migration.java"


# instance fields
.field public final endVersion:I

.field public final startVersion:I


# direct methods
.method public constructor <init>(II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Landroid/arch/persistence/room/migration/Migration;->startVersion:I

    iput p2, p0, Landroid/arch/persistence/room/migration/Migration;->endVersion:I

    return-void
.end method


# virtual methods
.method public abstract migrate(Landroid/arch/persistence/db/SupportSQLiteDatabase;)V
.end method
