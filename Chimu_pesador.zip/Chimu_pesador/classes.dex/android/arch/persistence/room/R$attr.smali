.class public final Landroid/arch/persistence/room/R$attr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/arch/persistence/room/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final font:I = 0x7f0400a7

.field public static final fontProviderAuthority:I = 0x7f0400a9

.field public static final fontProviderCerts:I = 0x7f0400aa

.field public static final fontProviderFetchStrategy:I = 0x7f0400ab

.field public static final fontProviderFetchTimeout:I = 0x7f0400ac

.field public static final fontProviderPackage:I = 0x7f0400ad

.field public static final fontProviderQuery:I = 0x7f0400ae

.field public static final fontStyle:I = 0x7f0400af

.field public static final fontWeight:I = 0x7f0400b0


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
