.class public final Landroid/arch/lifecycle/extensions/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/arch/lifecycle/extensions/R$attr;,
        Landroid/arch/lifecycle/extensions/R$bool;,
        Landroid/arch/lifecycle/extensions/R$color;,
        Landroid/arch/lifecycle/extensions/R$dimen;,
        Landroid/arch/lifecycle/extensions/R$drawable;,
        Landroid/arch/lifecycle/extensions/R$id;,
        Landroid/arch/lifecycle/extensions/R$integer;,
        Landroid/arch/lifecycle/extensions/R$layout;,
        Landroid/arch/lifecycle/extensions/R$string;,
        Landroid/arch/lifecycle/extensions/R$style;,
        Landroid/arch/lifecycle/extensions/R$styleable;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
