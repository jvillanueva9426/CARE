.class public final Landroid/support/coreutils/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/coreutils/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final action_container:I = 0x7f09000e

.field public static final action_divider:I = 0x7f090010

.field public static final action_image:I = 0x7f090011

.field public static final action_text:I = 0x7f090019

.field public static final actions:I = 0x7f09001a

.field public static final async:I = 0x7f090022

.field public static final blocking:I = 0x7f090026

.field public static final chronometer:I = 0x7f09005b

.field public static final forever:I = 0x7f090081

.field public static final icon:I = 0x7f090089

.field public static final icon_group:I = 0x7f09008b

.field public static final info:I = 0x7f09009a

.field public static final italic:I = 0x7f09009c

.field public static final line1:I = 0x7f0900b4

.field public static final line3:I = 0x7f0900b5

.field public static final normal:I = 0x7f0900c3

.field public static final notification_background:I = 0x7f0900c4

.field public static final notification_main_column:I = 0x7f0900c5

.field public static final notification_main_column_container:I = 0x7f0900c6

.field public static final right_icon:I = 0x7f0900d9

.field public static final right_side:I = 0x7f0900da

.field public static final tag_transition_group:I = 0x7f09010c

.field public static final text:I = 0x7f09010d

.field public static final text2:I = 0x7f09010e

.field public static final time:I = 0x7f090124

.field public static final title:I = 0x7f090125


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
