.class public final Landroid/support/constraint/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/constraint/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final bottom:I = 0x7f090027

.field public static final end:I = 0x7f090074

.field public static final gone:I = 0x7f090083

.field public static final invisible:I = 0x7f09009b

.field public static final left:I = 0x7f0900b2

.field public static final packed:I = 0x7f0900c7

.field public static final parent:I = 0x7f0900c9

.field public static final percent:I = 0x7f0900d1

.field public static final right:I = 0x7f0900d8

.field public static final spread:I = 0x7f090100

.field public static final spread_inside:I = 0x7f090101

.field public static final start:I = 0x7f090107

.field public static final top:I = 0x7f090130

.field public static final wrap:I = 0x7f09019b


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
