.class public final Landroid/support/coreui/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/coreui/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final notification_action_color_filter:I = 0x7f06005e

.field public static final notification_icon_bg_color:I = 0x7f06005f

.field public static final ripple_material_light:I = 0x7f06006a

.field public static final secondary_text_default_material_light:I = 0x7f06006c


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
